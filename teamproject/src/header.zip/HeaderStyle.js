import styled from "styled-components";

export const HeaderWrapper = styled.div`
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  grid-row: 1;
`;
