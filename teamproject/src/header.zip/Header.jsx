import Logo from '../asset/logo.png';

function Header() {
    return(
    <>
        <div className="header__logo">
            <a href="/"> 
                <img className="logo" src={Logo} alt="로고"/>
            </a>
        </div>
        <div/>
        <div/>
        <a href="../mypage/Mypage.jsx"> 
            <img src="" alt="장바구니"/>
        </a>
    </>
    )
}

export default Header;